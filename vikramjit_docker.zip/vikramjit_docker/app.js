const express = require('express');
const app = express();
const PORT = 3000;

app.get('/', (req, res) => {
 
    res.send('My name is Vikramjit Singh and my id is C0893714');
  });

// Middleware to parse JSON bodies
app.use(express.json());

// Dummy data - replace this with a database setup in real scenarios
let nodes = [
    { id: 1, name: 'Node 1' },
    { id: 2, name: 'Node 2' },
    { id: 3, name: 'Node 3' },
    { id: 4, name: 'Node 4' },
    { id: 5, name: 'Node 5' }
];

// Routes
// GET all nodes
app.get('/api/nodes', (req, res) => {
    res.json(nodes);
});

// GET a single node
app.get('/api/nodes/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const node = nodes.find(node => node.id === id);
    if (!node) {
        res.status(404).send('Node not found');
    } else {
        res.json(node);
    }
});

// POST a new node
app.post('/api/nodes', (req, res) => {
    const newNode = {
        id: nodes.length + 1,
        name: req.body.name
    };
    nodes.push(newNode);
    res.status(201).json(newNode);
});

// PUT update a node
app.put('/api/nodes/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const node = nodes.find(node => node.id === id);
    if (!node) {
        res.status(404).send('Node not found');
    } else {
        node.name = req.body.name;
        res.json(node);
    }
});

// DELETE a node
app.delete('/api/nodes/:id', (req, res) => {
    const id = parseInt(req.params.id);
    nodes = nodes.filter(node => node.id !== id);
    res.json(nodes);
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});